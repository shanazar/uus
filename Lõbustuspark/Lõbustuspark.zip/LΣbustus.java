package Lõbustuspark;

public interface Lõbustus {
    void lõbusta(Külastaja külastaja);
}
